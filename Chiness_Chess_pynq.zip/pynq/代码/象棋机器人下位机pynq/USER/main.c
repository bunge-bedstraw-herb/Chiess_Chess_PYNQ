/*
2019���ҵ������������
���� ����
ʱ�� 2019.3.29
*/

/*
ͨ��Э��
Э��ͷ��FE+��ʼ����x+��ʼ����y+��ֹ����x+��ֹ����y+���ӱ�־+Э��β��0D 0A
*/

#include "led.h"
#include "delay.h"
#include "OLED.h"
#include "key.h" 
#include "usart.h"
#include "stdio.h"
#include "OLED.h"
#include "A4988.h"
#include "dma.h"
#include "time.h"

/*��ԭ�㵽�������������*/
const int LocationChess[14][9][2]={
{{0,0},{-12,350},{-24,700},{-36,1050},{-48,1400},{-60,1750},{-72,2100},{-84,2450},{-96,2800}},
{{350,0+9},{350-12,350+9},{350-24,700+9},{350-36,1050+9},{350-48,1400+9},{350-60,1750+9},{350-72,2100+9},{350-84,2450+9},{350-96,2800+9}},
{{700,0+18},{700-12,350+18},{700-24,700+18},{700-36,1050+18},{700-48,1400+18},{700-60,1750+18},{700-72,2100+18},{700-84,2450+18},{700-96,2800+18}},
{{1050,0+27},{1050-12,350+27},{1050-24,700+27},{1050-36,1050+27},{1050-48,1400+27},{1050-60,1750+27},{1050-72,2100+27},{1050-84,2450+27},{1050-96,2800+27}},
{{1400,0+36},{1400-12,350+36},{1400-24,700+36},{1400-36,1050+36},{1400-48,1400+36},{1400-60,1750+36},{1400-72,2100+36},{1400-84,2450+36},{1400-96,2800+36}},
{{1750,0+45},{1750-12,350+45},{1750-24,700+45},{1750-36,1050+45},{1750-48,1400+45},{1750-60,1750+45},{1750-72,2100+45},{1750-84,2450+45},{1750-96,2800+45}},
{{2100,0+54},{2100-12,350+54},{2100-24,700+54},{2100-36,1050+54},{2100-48,1400+54},{2100-60,1750+54},{2100-72,2100+54},{2100-84,2450+54},{2100-96,2800+54}},
{{2450,0+63},{2450-12,350+63},{2450-24,700+63},{2450-36,1050+63},{2450-48,1400+63},{2450-60,1750+63},{2450-72,2100+63},{2450-84,2450+63},{2450-96,2800+63}},
{{2800,0+72},{2800-12,350+72},{2800-24,700+72},{2800-36,1050+72},{2800-48,1400+72},{2800-60,1750+72},{2800-72,2100+72},{2800-84,2450+72},{2800-96,2800+72}},
{{3150,0+81},{3150-12,350+81},{3150-24,700+81},{3150-36,1050+81},{3150-48,1400+81},{3150-60,1750+81},{3150-72,2100+81},{3150-84,2450+81},{3150-96,2800+81}},
{{3500,0+90},{3500-12,350+90},{3500-24,700+90},{3500-36,1050+90},{3500-48,1400+90},{3500-60,1750+90},{3500-72,2100+90},{3500-84,2450+90},{3500-96,2800+90}},
{{3850,0+99},{3850-12,350+99},{3850-24,700+99},{3850-36,1050+99},{3850-48,1400+99},{3850-60,1750+99},{3850-72,2100+99},{3850-84,2450+99},{3850-96,2800+99}},
{{4200,0+108},{4200-12,350+108},{4200-24,700+108},{4200-36,1050+108},{4200-48,1400+108},{4200-60,1750+108},{4200-72,2100+108},{4200-84,2450+108},{4200-96,2800+108}},
{{4550,0+116},{4550-12,350+116},{4550-24,700+116},{4550-36,1050+116},{4550-48,1400+116},{4550-60,1750+116},{4550-72,2100+116},{4550-84,2450+116},{4550-96,2800+116}}
};

/*���Ӱڷŵ�λ��*/
const u8 EatChessPos[1][18][2]={
	{{1,8},{0,8},{1,7},{0,7},{1,6},{0,6},{1,5},{0,5},{1,4},{0,4},{1,3},{0,3},{1,2},{0,2},{1,1},{0,1},{0,1},{0,0}}
};

int main(void)
{		
		u8 flag=0,state=0,RunFlag=0;
		u8 Chesscount=0,modecount=1,modestate;//���Ӹ����ļ�¼
	  int c = 0;
		delay_init();	    	 //��ʱ������ʼ��	  
		NVIC_Configuration(); 	 //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
		uart_init(9600);
		LED_Init();
		Electromagnet_Init();
		KEY_Init();
		IIC_Init();
		OLED_Init();
		A_A4988_Init();
		B_A4988_Init();
		C_A4988_Init();
		TIM1_PWM_Init();
		DMA_Configuration();
		OLED_Fill(0x00);       //����
		UI();
		while(1)
		{
		//����ѡ��
			modestate=KEY_Scan(0);
			switch(modestate)
			{
				case 2:
					if(modecount>1) modecount--;
					ClearMark();
					ShowMark(modecount);
					break;
				case 3:
					if(modecount<3) modecount++;
					ClearMark();
					ShowMark(modecount);
					break;
				case 4:
					OLED_ShowStr(112,4,"P",2);//����
					for(c=0;c<10;c++)
				  {					
					USART_SendData(USART1,0x40);//��ʼ����
					delay_us(20);
					}
					break;
				case 5:
					OLED_ShowStr(112,4,"I",2);//�м�
					for(c=0;c<10;c++)
				  {					
					USART_SendData(USART1,0x50);//��ʼ����
					delay_us(20);
					}
					break;
				case 6:
					if(modecount==1)	
					{
						RunFlag=1;
					for(c=0;c<10;c++)
				  {					
					USART_SendData(USART1,0x10);//��ʼ����
					delay_us(20);
					}
					}
					else if(modecount==2)
					{
						RunFlag=0;
						OLED_ShowStr(112,0,"S",2);
						for(c=0;c<10;c++)
						{					
						USART_SendData(USART1,0x20);//��ͣ
						delay_us(20);
						}
					}
					else if(modecount==3)
					{
						RunFlag=2;
						OLED_ShowStr(112,0,"S",2);
						for(c=0;c<10;c++)
						{					
						USART_SendData(USART1,0x30);//��ͣ
						delay_us(20);
						}
						Chesscount=0;
						
					}
					break;
				default:break;
					/*
				USART_SendData(USART1,0xAA);
				delay_us(20);
				USART_SendData(USART1,0xBB);
				delay_us(20);
				*/
			}

			if((USART_RX_STA&0x8000))//�������
			{
				A_EN=0;
				B_EN=0;
				C_EN=0;
				//USART_SendData(USART1,USART_RX_BUF[5]);
				//delay_us(20);
				if(USART_RX_BUF[5]==0)
				{
					flag=1;//������
				}
				else if(USART_RX_BUF[5]==1)
				{
					flag=2;//����
				}
				else if(USART_RX_BUF[5]==2||USART_RX_BUF[5]==3)//����ʤ�������ʤ
				{
					flag=3;
					A_EN=1;
					B_EN=1;
					C_EN=1;
					RunFlag=2;
				}
				
//				if(flag==0)
//				{
					CheckHead=0;
					USART_RX_STA=0;
//				}
			}
/*
ͨ��Э��
Э��ͷ��FE+��ʼ����x+��ʼ����y+��ֹ����x+��ֹ����y+���ӱ�־+Э��β��0D 0A
*/
			if(flag==1)
			{
				switch(state)
				{
					case 0:
						StepMotoX(LocationChess[USART_RX_BUF[1]][USART_RX_BUF[2]][0]);
						StepMotoY(LocationChess[USART_RX_BUF[1]][USART_RX_BUF[2]][1]);
						state++;
						break;
					case 1:
						if(FlagX&&FlagY)	
						{
							state++;
							FlagX=0;
							FlagY=0;
						}
						break;
					case 2:
						StepMotoZ(1);
						state++;
					break;
					case 3:
						if(FlagZ)	
						{
							state++;
							Electromagnet=1;
							FlagZ=0;
						}
						break;
					case 4:
						StepMotoZ(0);
						state++;
						break;
					case 5:
						if(FlagZ)
						{
							StepMotoX(LocationChess[USART_RX_BUF[3]][USART_RX_BUF[4]][0]-LocationChess[USART_RX_BUF[1]][USART_RX_BUF[2]][0]);
							StepMotoY(LocationChess[USART_RX_BUF[3]][USART_RX_BUF[4]][1]-LocationChess[USART_RX_BUF[1]][USART_RX_BUF[2]][1]);
							state++;
							FlagZ=0;
						}
						break;
					case 6:
						if(FlagX&&FlagY)	
						{
							state++;
							FlagX=0;
							FlagY=0;
						}
						break;
					case 7:
						StepMotoZ(1);
						state++;
						break;
					case 8:
						if(FlagZ)	
						{
							state++;
							Electromagnet=0;
							FlagZ=0;
						}
						break;
					case 9:
						StepMotoZ(0);
						state++;
						break;
					case 10:
						if(FlagZ)	
						{
							state++;
							StepMotoX(-LocationChess[USART_RX_BUF[3]][USART_RX_BUF[4]][0]);
							StepMotoY(-LocationChess[USART_RX_BUF[3]][USART_RX_BUF[4]][1]);
							FlagZ=0;
						}
						break;
					case 11:
						if(FlagX&&FlagY)	
						{
							state++;
							FlagX=0;
							FlagY=0;
						}
						break;
					case 12:
						//�򴮿ڷ���������ɵ�����
						if(RunFlag==1)
						{
						for(c=0;c<10;c++)
						{					
						USART_SendData(USART1,0x10);//��ͣ
						delay_us(20);
						}
						}
						else if(RunFlag==2)	
							Chesscount=0;
						
						state=0;
						flag=0;
						delay_ms(500);
						A_EN=1;
						B_EN=1;
						C_EN=1;
						if(modestate==6&&modecount==2)
							Chesscount=0;
						break;
					default:break;
				}
			}
			else if(flag==2)
			{
				switch(state)
				{
					case 0:
						StepMotoX(LocationChess[USART_RX_BUF[3]][USART_RX_BUF[4]][0]);
						StepMotoY(LocationChess[USART_RX_BUF[3]][USART_RX_BUF[4]][1]);
						state++;
						break;
					case 1:
						if(FlagX&&FlagY)	
						{
							state++;
							FlagX=0;
							FlagY=0;
						}
						break;
					case 2:
						StepMotoZ(1);
						state++;
					break;
					case 3:
						if(FlagZ)	
						{
							state++;
							Electromagnet=1;
							FlagZ=0;
						}
						break;
					case 4:
						StepMotoZ(0);
						state++;
						break;
					case 5:
						if(FlagZ)
						{
							FlagZ=0;
							StepMotoX(LocationChess[EatChessPos[0][Chesscount][0]][EatChessPos[0][Chesscount][1]][0]-LocationChess[USART_RX_BUF[3]][USART_RX_BUF[4]][0]);
							StepMotoY(LocationChess[EatChessPos[0][Chesscount][0]][EatChessPos[0][Chesscount][1]][1]-LocationChess[USART_RX_BUF[3]][USART_RX_BUF[4]][1]);
							state++;
						}
						break;
					case 6:
						if(FlagX&&FlagY)	
						{
							state++;
							FlagX=0;
							FlagY=0;
						}
						break;
					case 7:
						StepMotoZ(1);
						state++;
						break;
					case 8:
						if(FlagZ)	
						{
							state++;
							Electromagnet=0;
							FlagZ=0;
						}
						break;
					case 9:
						StepMotoZ(0);
						state++;
						break;
					case 10:
						if(FlagZ)	
						{
							state++;
							StepMotoX(LocationChess[USART_RX_BUF[1]][USART_RX_BUF[2]][0]-LocationChess[EatChessPos[0][Chesscount][0]][EatChessPos[0][Chesscount][1]][0]);
							StepMotoY(LocationChess[USART_RX_BUF[1]][USART_RX_BUF[2]][1]-LocationChess[EatChessPos[0][Chesscount][0]][EatChessPos[0][Chesscount][1]][1]);
							Chesscount++;
							FlagZ=0;
						}
						break;
					case 11:
						if(FlagX&&FlagY)	
						{
							state++;
							FlagX=0;
							FlagY=0;
						}
						break;
					case 12:
						StepMotoZ(1);
						state++;
					break;
					case 13:
						if(FlagZ)	
						{
							state++;
							Electromagnet=1;
							FlagZ=0;
						}
						break;
					case 14:
						StepMotoZ(0);
						state++;
						break;
					case 15:
						if(FlagZ)
						{
							StepMotoX(LocationChess[USART_RX_BUF[3]][USART_RX_BUF[4]][0]-LocationChess[USART_RX_BUF[1]][USART_RX_BUF[2]][0]);
							StepMotoY(LocationChess[USART_RX_BUF[3]][USART_RX_BUF[4]][1]-LocationChess[USART_RX_BUF[1]][USART_RX_BUF[2]][1]);
							state++;
							FlagZ=0;
						}
						break;
					case 16:
						if(FlagX&&FlagY)	
						{
							state++;
							FlagX=0;
							FlagY=0;
						}
						break;
					case 17:
						StepMotoZ(1);
						state++;
						break;
					case 18:
						if(FlagZ)	
						{
							state++;
							Electromagnet=0;
							FlagZ=0;
						}
						break;
					case 19:
						StepMotoZ(0);
						state++;
						break;
					case 20:
						if(FlagZ)	
						{
							state++;
							StepMotoX(-LocationChess[USART_RX_BUF[3]][USART_RX_BUF[4]][0]);
							StepMotoY(-LocationChess[USART_RX_BUF[3]][USART_RX_BUF[4]][1]);
							FlagZ=0;
						}
						break;
					case 21:
						if(FlagX&&FlagY)	
						{
							state++;
							FlagX=0;
							FlagY=0;
						}
						break;
					case 22:
						//�򴮿ڷ���������ɵ�����
						if(RunFlag==1)
						{
						for(c=0;c<10;c++)
						{					
						USART_SendData(USART1,0x10);//��ͣ
						delay_us(20);
						}
						}
						else if(RunFlag==2)	
							Chesscount=0;
						state=0;
						flag=0;
						delay_ms(500);
						A_EN=1;
						B_EN=1;
						C_EN=1;
						if(modestate==6&&modecount==2)
							Chesscount=0;
						break;
					default:break;
				}
			}
			else if(flag==3)//��һ���� �������
			{
				flag=0;
				Chesscount=0;
			}
		}

}

