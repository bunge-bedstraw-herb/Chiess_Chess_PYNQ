#ifndef __DMA_H
#define	__DMA_H	   
#include "sys.h"
#define TIM1_CCR1_Address    ((uint32_t)0x40012C34) //TIM1ͨ��1�ȽϼĴ���
#define TIM1_CCR2_Address    ((uint32_t)0x40012C38) //TIM1ͨ��2�ȽϼĴ���
#define TIM1_ARR_Address    ((uint32_t)0x40012C2C)  //TIM1�Զ�װ�ؼĴ���

extern u8 FlagX;
extern u8 FlagY;
extern u8 FlagZ;

void DMA_Configuration(void);

void DMA_Enable(DMA_Channel_TypeDef *DMA_CHx,uint16_t TIM_Channel,u16 PluseNum);

void StepMotoX(s16 pulse);
void StepMotoY(s16 pulse);
void StepMotoZ(s8 dir);
#endif
