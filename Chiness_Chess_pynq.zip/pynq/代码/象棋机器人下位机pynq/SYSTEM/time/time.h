#ifndef __TIME_H
#define __TIME_H
#include "sys.h"

void TIM1_PWM_Init(void);


#endif

