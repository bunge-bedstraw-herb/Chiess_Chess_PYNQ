/********************************
1~9  ��Ӧ1~9
10--A
11--B
12--C
13--D
14--*
15--0
16--#
********************************/
#include "key_Parl.h"
#include "delay.h"

#define Line1 PAout(7)  //�������
#define Line2 PCout(1)
#define Line3 PCout(2)
#define Line4 PCout(3)
#define Hon1 PCin(6)     //��������
#define Hon2 PCin(7)
#define Hon3 PCin(8)
#define Hon4 PCin(9)
/*IO������*/
void Key_P_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);	 //ʹ��PC�˿�ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	 //ʹ��PC�˿�ʱ��

/*����ܽ�*/

		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 ;				 //LED0-->PD.2 �˿�����
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
		GPIO_Init(GPIOC, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOD
		GPIO_SetBits(GPIOC,GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3);
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
		GPIO_Init(GPIOA, &GPIO_InitStructure);
		GPIO_SetBits(GPIOA,GPIO_Pin_7);
		
/*����ܽ�*/	

		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;				 //LED0-->PD.2 �˿�����
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 		 //��������
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
		GPIO_Init(GPIOC, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOD
}

/*��������ֵ*/
u8 Return_Data(void)
{
	u8 code;
	Line1=0;Line2=0;Line3=0;Line4=0;  //��ֵΪ0
  code=(GPIOC->IDR)>>6;	            
	code&=0x0f;
	if(code==0X0F) return 0;
	else {
		delay_ms(10);
	Line1=1;Line2=1;Line3=1;Line4=1; //��Ϊ1
	switch(code) {
		case(7):  Line1=0;if(!Hon4){while(!Hon4);return 10;}//1��0111
		          Line2=0;if(!Hon4){while(!Hon4);return 11;}
		          Line3=0;if(!Hon4){while(!Hon4);return 12;}
		          Line4=0;if(!Hon4){while(!Hon4); return 13;}break;
		case(11):  Line1=0;if(!Hon3){while(!Hon3); return 3;}//2��1011
		          Line2=0;if(!Hon3){while(!Hon3); return 6;}
		          Line3=0;if(!Hon3){while(!Hon3); return 9;}
		          Line4=0;if(!Hon3){while(!Hon3); return 16;}break;
		case(13):  Line1=0;if(!Hon2){while(!Hon2); return 2;}//3��1101
		          Line2=0;if(!Hon2){while(!Hon2); return 5;}
		          Line3=0;if(!Hon2){while(!Hon2); return 8;}
		          Line4=0;if(!Hon2){while(!Hon2); return 0;}break;
		case(14):  Line1=0;if(!Hon1){while(!Hon1); return 1;}//4��1110
		          Line2=0;if(!Hon1) {while(!Hon1);return 4;}
		          Line3=0;if(!Hon1) {while(!Hon1);return 7;}
		          Line4=0;if(!Hon1) {while(!Hon1);return 14;}break;	
		default:return 0;		
	  }
  }
	return 0;
}
