#ifndef __KEY_PARL_H
#define __KEY_PARL_H
#include "sys.h"

void Key_P_Init(void);
u8 Return_Data(void);
#endif
