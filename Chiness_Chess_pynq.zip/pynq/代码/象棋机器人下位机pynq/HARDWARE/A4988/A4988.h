#ifndef __A4988_H
#define __A4988_H

#include "sys.h"

#define A_EN   PCout(0)
#define A_MS1  PCout(1)
#define A_MS2  PCout(2)
#define A_MS3  PCout(3)
#define A_SLP  PCout(4)
#define A_DIR  PCout(5)

#define B_EN   PCout(6)
#define B_MS1  PCout(7)
#define B_MS2  PCout(8)
#define B_MS3  PCout(9)
#define B_SLP  PCout(10)
#define B_DIR  PCout(11)

#define C_EN   PBout(10)
#define C_MS1  PBout(11)
#define C_MS2  PBout(12)
#define C_MS3  PBout(13)
#define C_SLP  PBout(14)
#define C_DIR  PBout(15)


#define A_Full_step {A_MS1 = 0;A_MS2 = 0;A_MS3 = 0;}                  
#define A_Half_step {A_MS1 = 1;A_MS2 = 0;A_MS3 = 0;}
#define A_Quarter_step {A_MS1 = 0;A_MS2 = 1;A_MS3 = 0;} 
#define A_Eighth_step {A_MS1 = 1;A_MS2 = 1;A_MS3 = 0;}
#define A_Sixteenth_step {A_MS1 = 1;A_MS2 = 1;A_MS3 = 1;} 

#define B_Full_step {B_MS1 = 0;B_MS2 = 0;B_MS3 = 0;}                  
#define B_Half_step {B_MS1 = 1;B_MS2 = 0;B_MS3 = 0;}
#define B_Quarter_step {B_MS1 = 0;B_MS2 = 1;B_MS3 = 0;} 
#define B_Eighth_step {B_MS1 = 1;B_MS2 = 1;B_MS3 = 0;}
#define B_Sixteenth_step {B_MS1 = 1;B_MS2 = 1;B_MS3 = 1;} 

#define C_Full_step {C_MS1 = 0;C_MS2 = 0;C_MS3 = 0;}                  
#define C_Half_step {C_MS1 = 1;C_MS2 = 0;C_MS3 = 0;}
#define C_Quarter_step {C_MS1 = 0;C_MS2 = 1;C_MS3 = 0;} 
#define C_Eighth_step {C_MS1 = 1;C_MS2 = 1;C_MS3 = 0;}
#define C_Sixteenth_step {C_MS1 = 1;C_MS2 = 1;C_MS3 = 1;} 

void A_A4988_Init(void);
void B_A4988_Init(void);
void C_A4988_Init(void);

#endif
