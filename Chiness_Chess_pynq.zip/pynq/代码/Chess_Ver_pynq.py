# -*- coding: utf-8 -*-
import cv2
import numpy as np
import matplotlib.pyplot as plt
import time
import numpy as np
import ctypes
from ctypes import *
from pynq.overlays.base import BaseOverlay
from pynq.lib import MicroblazeLibrary

Mode=3

def Send_Data(Fromx,Fromy,Tox,Toy,EatFlag):
    SendData[1]=Fromx
    SendData[2]=Fromy
    SendData[3]=Tox
    SendData[4]=Toy
    SendData[5]=EatFlag
   # for i in range(0,8):
    lib_uart.uart_write(device_uart,Send_Data, len(Send_Data))
    time.sleep(0.1)

def Waitflag():
    global Mode
    while(1):
        recv = [0xFF,0XFF]
        lib.uart_read(device_uart,recv,len(recv))
        print 'recv[0]=%d,recv[1]=%d'%(ord(recv[0]),ord(recv[1]))
        if ord(recv [0])==0xAA  and ord(recv [1])==0x10:
            #print "ok"
            recv = [0xFF,0XFF]
            time.sleep(0.1)
            return 1
        elif ord(recv [0])==0xAA  and ord(recv [1])==0x20:
            robot_speech_direction(0x16)
        elif ord(recv [0])==0xAA and ord(recv [1])==0x30:
            robot_speech_direction(0x0F)
            #Send_Data(0,0,0,0,2)
            print "You are lost"
            #lib.StartPlay(16)
            recv = [0xFF,0XFF]
            time.sleep(0.1)
            return 0
        elif ord(recv [0])==0xAA and ord(recv [1])==0x40:
            Mode=3
            robot_speech_direction(0x19)
        elif ord(recv [0])==0xAA and ord(recv [1])==0x50:
            Mode=4
            robot_speech_direction(0x20)
        recv = [0xFF,0XFF]
        time.sleep(0.1)

def robot_speech_chess(a):
    info = "/home/xilinx/Music/"
    switcher = {
    32: 'jiang.mp3',  
    33 : 'shi.mp3',
    34 : 'shi.mp3',
    35 : 'xiang.mp3',
    36 : 'xiang.mp3',
    37 : 'ma.mp3',
    38 : 'ma.mp3',
    39 : 'ju.mp3',
    40 : 'ju.mp3',
    41 : 'pao.mp3',
    42 : 'pao.mp3',
    43 : 'zu.mp3',
    44 : 'zu.mp3',
    45 : 'zu.mp3',
    46 : 'zu.mp3',
    47 : 'zu.mp3',
    }
    filename = switcher[a] 
    filepath = info + filename
    pAudio.load(filepath)
    pAudio.play()

def robot_speech_number(a):
    info = "/home/xilinx/Music/"
    switcher = {
    1 : '1.mp3',
    2 : '2.mp3',
    3 : '3.mp3',
    4 : '4.mp3',
    5 : '5.mp3',
    6 : '6.mp3',
    7 : '7.mp3',
    8 : '8.mp3',
    9 : '9.mp3',
    }
    filename = switcher[a] 
    filepath = info + filename
    pAudio.load(filepath)
    pAudio.play()

def robot_speech_direction(a):
    info = "/home/xilinx/Music/"
    switcher = {
    0x30 : 'ping.mp3',
    0x31 : 'jing.mp3',
    0x32 : 'tui.mp3',
    0x0B:'begin.mp3',
    0x0C:'your_turn.mp3',
    0x0D:'wozou.mp3',
    0x0E:'wrong.mp3',
    0x0F:'lose.mp3',
    0x10:'win.mp3',
    0x11:'wochiqi.mp3',
    0x12:'no_detect.mp3',
    0x14:'time_over.mp3',
    0x16:'pause.mp3',
    0x18:'start_game.mp3',
    0x19:'primary.mp3',
    0x20:'middle.mp3'
    }
    filename = switcher[a] 
    filepath = info + filename
    pAudio.load(filepath)
    pAudio.play()
    
def Normalized(List):
    CheckFlag=0
    #Chess_Board_Xposition=[528,628,728,828,928,1028,1128,1228,1328,1428]
    Chess_Board_Xposition=[1428,1328,1228,1128,1028,928,828,728,628,528]
    #Chess_Board_Yposition=[139,239,339,439,539,639,739,839,939]
    Chess_Board_Yposition=[939,839,739,639,539,439,339,239,139]
    ChessPiece=[0 for i in range(0,256)]
    for i in List[:]:
        for j in range(0,10):
             if abs(i[0]-Chess_Board_Xposition[j])<50:
                 break
             if j==9:
                CheckFlag=1
        for z in range(0,9):
            if abs(i[1]-Chess_Board_Yposition[z])<50:
                 break
            if z==9:
                CheckFlag=1;
        if CheckFlag==1:
            CheckFlag=0
            continue
        else:
            ChessPiece[(j+3)*16+8-z+3]=1
        #print j,8-z
        #print (j+3)*16+8-z+3
    return ChessPiece
        
        
def CatchPlayerGo():
    global Mode
    count=0
    while(1):
   
        camera = cv2.VideoCapture('/dev/video0') # 参数0表示第一个摄像头
        camera.set(3,1600)
        camera.set(4,1200)
        '''
        if (camera.isOpened()):
            print('Usb Camera is Open')
        else:
            print('Usb Camera not Open')
            '''
        count_1=0;
        count1=0;
        ret, img1 = camera.read()
        HSV = cv2.cvtColor(img1, cv2.COLOR_BGR2HSV)#把BGR图像转换为HSV格式
        
        Lower = np.array([156, 40, 46]) #要识别颜色的下限
        Upper = np.array([180, 255, 255])#要识别的颜色的上限
        
        #mask是把HSV图片中在颜色范围内的区域变成白色，其他区域变成黑色
        mask = cv2.inRange(HSV, Lower, Upper)

        while(1):
            img1_circle_result= cv2.HoughCircles(mask, cv2.HOUGH_GRADIENT, 1, 55, param1=1000, param2=16, minRadius=28, maxRadius=44)#55 1000 14 30
            if(img1_circle_result is None):
                camera.release()
                camera = cv2.VideoCapture('/dev/video0') # 参数0表示第一个摄像头
                camera.set(3,1600)
                camera.set(4,1200)
                '''
                if (camera.isOpened()):
                    print('Usb Camera is Open')
                else:
                    print('Usb Camera not Open')
                    '''
                ret, img1 = camera.read()
                HSV = cv2.cvtColor(img1, cv2.COLOR_BGR2HSV)#把BGR图像转换为HSV格式
                
                Lower = np.array([156, 40, 46]) #要识别颜色的下限
                Upper = np.array([180, 255, 255])#要识别的颜色的上限
                
                #mask是把HSV图片中在颜色范围内的区域变成白色，其他区域变成黑色
                mask = cv2.inRange(HSV, Lower, Upper)
            else:
                break;
        #print "ok"
        circles=np.uint16(np.around(img1_circle_result))

        for i in circles[0, :  ]:
            cv2.circle(img1,(i[0],i[1]),i[2],(255,0,0),5)
            cv2.circle(img1,(i[0],i[1]),2,(255,0,0),10)
        #cv2.imwrite('/home/pi/TheAllProcedures/pic/test.png',img1)
        '''
        plt.subplot(122), plt.imshow(img1)
        plt.title('circle'), plt.xticks([]), plt.yticks([])
        plt.show()
        '''
        ChessPiece2=Normalized(circles[0])
        camera.release()
        #print ChessPiece1
        #print ChessPiece2
        for i in range(0,255):
            if ChessPiece1[i]-ChessPiece2[i]==1:
                count_1=count_1+1;
                LastPos=i
            if ChessPiece1[i]-ChessPiece2[i]==-1:
                count1=count1+1;
                NowPos=i
                
        if count_1==1 and count1==1:
            ChessResultPlayer=lib.PlayerGo(LastPos,NowPos)
            print LastPos,NowPos
            if ChessResultPlayer==2:
                robot_speech_direction(0x10)
                Send_Data(0,0,0,0,2)
                return 1#player_win
            elif ChessResultPlayer==0:
                robot_speech_direction(0x0E)
                    #Error
            elif ChessResultPlayer==1:
                ChessPiece1[LastPos]=0
                ChessPiece1[NowPos]=1
                return 0
            #return LastPos,NowPos
        count=count+1
        #time.sleep(0.1)
        print count
        
        recv = [0xFF,0XFF]
        lib.uart_read(device_uart,recv,len(recv))
        print 'recv[0]=%d,recv[1]=%d'%(ord(recv[0]),ord(recv[1]))
        if ord(recv [0])==0xAA  and ord(recv [1])==0x20:
            robot_speech_direction(0x16)
            recv = [0xFF,0XFF]
            while(1):
                lib.uart_read(device_uart,recv,len(recv))
                #print 'recv[0]=%d,recv[1]=%d'%(ord(recv[0]),ord(recv[1]))
                if ord(recv [0])==0xAA  and ord(recv [1])==0x10:
                    #print "ok"
                    #ser.flushInput()
                    #time.sleep(0.1)
                    robot_speech_direction(0x0C)
                    break
                elif ord(recv [0])==0xAA and ord(recv [1])==0x30:
                    robot_speech_direction(0x0F)
                    #Send_Data(0,0,0,0,2)
                    print "You are lost"
                    #lib.StartPlay(16)
                    time.sleep(0.1)
                    return 2
                elif ord(recv [0])==0xAA and ord(recv [1])==0x40:
                    Mode=3
                    robot_speech_direction(0x19)
                elif ord(recv [0])==0xAA and ord(recv [1])==0x50:
                    Mode=4
                    robot_speech_direction(0x20)
            elif ord(recv [0])==0xAA and ord(recv [1])==0x30:
                robot_speech_direction(0x0F)
                #Send_Data(0,0,0,0,2)
                print "You are lost"
                #lib.StartPlay(16)
                time.sleep(0.1)
                return 2
            elif ord(recv [0])==0xAA and ord(recv [1])==0x40:
                Mode=3
                robot_speech_direction(0x19)
            elif ord(recv [0])==0xAA and ord(recv [1])==0x50:
                Mode=4
                robot_speech_direction(0x20)
            
        if count>30:
            count=0
            robot_speech_direction(0x14)
            #Waitflag()
            
        '''
        count=ser.inWaiting()
        if count >=2:
            recv=ser.read(count)
            count = 0
            print 'recv[0]=%d,recv[1]=%d'%(ord(recv[0]),ord(recv[1]))
            if ord(recv [0])==0xAA  and ord(recv [1])==0x20:
                print "pause"
                ser.flushInput()
                time.sleep(0.1)
            elif ord(recv [0])==0xAA and ord(recv [1])==0x30:
                print "You are lost"
                ser.flushInput()
                time.sleep(0.1)
                return 2
            ser.flushInput()
            time.sleep(0.1)
            '''
            
if  __name__ == '__main__':
    base = BaseOverlay("base.bit")
    #音频初始化
    pAudio = base.audio
    pyduaio.select_microphone()
    pAudio.bypass(seconds=5)
    #串口初始化
    lib_uart = MicroblazeLibrary(base.RPI, ['uart'])
    device_uart = lib.uart_open(14,15)
    SendData=[0xFE,0,0,0,0,0,0x0D,0x0A]
    #引擎初始化
    so=ctypes.cdll.LoadLibrary
    lib=so("/home/pi/TheAllProcedures/libpycallclass.so")
    From=c_int*2
    To=c_int*2
    MoveFrom = From()
    MoveTo = To()
    MoveFrom[0] = 0
    MoveTo[0] = 0
    robot_speech_direction(0x0B)
    while(1):
        
        ChessPiece1=[
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0,
                 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0]
        
        lib.StartPlay(16)
        print "ok"

        while (1):
            if Waitflag()==1:
                break
        robot_speech_direction(0x18)
        time.sleep(1)
        #begin game
        while(1):
            
            robot_speech_direction(0x0C)
            Res=CatchPlayerGo()
            if Res==1 or Res==2:
                #robot_speech_direction(0x10)
                break
            
            '''
            elif: Res==2:
                robot_speech_direction(0x0F)
                break
                '''
            #print PlayerFrom,PlayGo
            '''
            ChessResultPlayer=lib.PlayerGo(PlayerFrom,PlayGo)
            if ChessResultPlayer==2:
                break#plager_win
            elif ChessResultPlayer==0:
                pass #Error
            '''
            
            ChessResultComputer=lib.ComputerGo(Mode, MoveFrom, MoveTo)
            MoveFromTrueX=(MoveFrom[0]+1)//16-1
            MoveFromTrueY=(MoveFrom[0])%16-3
            MoveToTrueX=(MoveTo[0]+1)//16-1
            MoveToTrueY=(MoveTo[0])%16-3
            if ChessResultComputer==2:
                robot_speech_direction(0x10)
                Send_Data(0,0,0,0,2)
                break #player_win
            elif ChessResultComputer==3:
                robot_speech_direction(0x0F)
                Send_Data(0,0,0,0,3)
                break #computer_win
            elif ChessResultComputer==1:
                ChessPiece1[MoveTo[0]]=0
                Send_Data(MoveFromTrueX,MoveFromTrueY,MoveToTrueX,MoveToTrueY,1)
                #print MoveFromTrueX-2,MoveFromTrueY,MoveToTrueX-2,MoveToTrueY
                if MoveFromTrueX==MoveToTrueX:
                    robot_speech_direction(0x0D)
                    robot_speech_chess(lib.GetChessPieceValue(MoveToTrueX,MoveToTrueY))
                    #print lib.GetChessPieceValue(MoveToTrueX,MoveToTrueY)
                    #robot_speech_chess(37)
                    robot_speech_number(MoveFromTrueY+1)
                    robot_speech_direction(0x30)
                    robot_speech_number(MoveToTrueY+1)
                else:
                    robot_speech_direction(0x0D)
                    robot_speech_chess(lib.GetChessPieceValue(MoveToTrueX,MoveToTrueY))
                    #print lib.GetChessPieceValue(MoveToTrueX,MoveToTrueY)
                    robot_speech_number(MoveFromTrueY+1)
                    if MoveFromTrueX<MoveToTrueX:
                        robot_speech_direction(0x31)
                        robot_speech_number(abs(MoveToTrueX-MoveFromTrueX))
                    else:
                        robot_speech_direction(0x32)
                        robot_speech_number(abs(MoveToTrueX-MoveFromTrueX))
                robot_speech_direction(0x11)
            elif  ChessResultComputer==0:
                Send_Data(MoveFromTrueX,MoveFromTrueY,MoveToTrueX,MoveToTrueY,0)
                print MoveFromTrueX-2,MoveFromTrueY,MoveToTrueX-2,MoveToTrueY
                if MoveFromTrueX==MoveToTrueX:
                    robot_speech_direction(0x0D)
                    robot_speech_chess(lib.GetChessPieceValue(MoveToTrueX,MoveToTrueY))
                    #print lib.GetChessPieceValue(MoveToTrueX,MoveToTrueY)
                    #robot_speech_chess(37)
                    robot_speech_number(MoveFromTrueY+1)
                    robot_speech_direction(0x30)
                    robot_speech_number(MoveToTrueY+1)
                else:
                    robot_speech_direction(0x0D)
                    robot_speech_chess(lib.GetChessPieceValue(MoveToTrueX,MoveToTrueY))
                    #print lib.GetChessPieceValue(MoveToTrueX,MoveToTrueY)
                    robot_speech_number(MoveFromTrueY+1)
                    if MoveFromTrueX<MoveToTrueX:
                        robot_speech_direction(0x31)
                        robot_speech_number(abs(MoveToTrueX-MoveFromTrueX))
                    else:
                        robot_speech_direction(0x32)
                        robot_speech_number(abs(MoveToTrueX-MoveFromTrueX))
            
            Lostflag=Waitflag()#xiaweijiyouhua
            if Lostflag==0:
                break



